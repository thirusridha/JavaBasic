package test;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Scanner;

public class DateEx {
	public static void main(String[] args) throws ParseException, FileNotFoundException {
//		 Date objDate = new Date(); 
//		 SimpleDateFormat objSDF = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");
////		 System.out.println(objSDF.format(objDate));
////		System.out.println(new SimpleDateFormat("YYYY-MM-DD HH:mm:ss", Locale.ENGLISH).parse("08-06-2022 11:33:26"));
//		String s ="sridhar";
//		System.out.println(s.substring(3));
//		InputStream fileStream = new BufferedInputStream(new FileInputStream("E:/Disk/Office Work/Freelancing/WebSynergies/Workspace/Data/stepup.txt"));
//   	 	Scanner sc = new Scanner(fileStream).useDelimiter("\\A");
//   	 	
//        while(sc.hasNextLine()){
//           System.out.println(sc.hasNext());
//        }
		
		Double d=Double.parseDouble(null);
		System.out.println(d);
	}
}//java.io.BufferedInputStream@75a1cd57
