
public class NullEx
{
	public static void main(String[] args) {
		NullEx n = null;
		System.out.println(n.print());
	}

	private static String  print() {
		return "hi";	}
}
