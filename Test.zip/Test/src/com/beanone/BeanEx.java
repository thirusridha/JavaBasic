package com.beanone;
public class BeanEx 
{
	public int cube(int n){
		return n*n*n;
	}
}
